cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'

clear
echo -e "$cyan ..........$red [$green please$blue waite$red ]$cyan >>>>>>>>>>>.../"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green p*****$blue w****$red ]$cyan >>>>>>>>>>>....|"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green pl****$blue wa***$red ]$cyan >>>>>>>>>>>..../"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green plee**$blue wai**$red ]$cyan >>>>>>>>>>>.....|"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green plee**$blue wait.$red ]$cyan >>>>>>>>>>....../"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green plees*$blue waite$red ]$cyan >>>>>>>>>>......|"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green pleese$blue waite$red ]$cyan >>>>>>>>>......./"
sleep 0.2
clear
echo -e "$cyan ..........$red [$green pleese$blue waite$red ]$cyan >>>>>>>>>......./"
sleep 2

clear

#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




cd $HOME

chat(){
echo 'def kk(t):' > .sssss.py
echo '   import sys, time' >> .sssss.py
echo '   for txt in t + "\n":' >> .sssss.py
echo '        sys.stdout.write(txt)' >> .sssss.py
echo '        sys.stdout.flush()' >> .sssss.py
echo '        time.sleep(9. / 1000)' >> .sssss.py


echo 'h = "              \033[1;33m[\033[1;32m*\033[1;33m] your welcome in {\033[1;32m AHT.Hacker \033[1;33m} py [\033[1;35m Ahmed.Altorky \033[1;33m] "' >> .sssss.py
echo 'kk(h)' >> .sssss.py
python2 .sssss.py

}
chat2(){
echo 'def kk(t):' > .ssss.py
echo '   import sys, time' >> .ssss.py
echo '   for txt in t + "\n":' >> .ssss.py
echo '        sys.stdout.write(txt)' >> .ssss.py
echo '        sys.stdout.flush()' >> .ssss.py
echo '        time.sleep(9. / 2040)' >> .ssss.py



echo 'a = "   \033[1;34m[ 11 ]\033[1;36m Facebook 		 \033[1;34m[ 22 ]\033[1;36m Youtube"' >> .ssss.py
echo 'b = "  "' >> .ssss.py
echo 'c = "  		\033[1;32m[ 33 ]\033[1;33m UPDATE                   \033[1;31m[ 00 ]Exit"' >> .ssss.py
echo 'd = "  "' >> .ssss.py
echo 'e = "  \033[1;35m==A=L=T=O=R=K=Y==>>.[ 1 ]\033[1;32m Install Metasploit ........>\033[1;35m [ 11 ]\033[1;32m DDOOS Attak "' >> .ssss.py
echo 'f = "  "' >> .ssss.py
echo 'g = "  \033[1;35m==A=L=T=O=R=K=Y==>>...[ 2 ]\033[1;32m open metasploit ............>\033[1;35m [ 12 ]\033[1;32m Fiza card"' >> .ssss.py
echo 'h = "  "' >> .ssss.py
echo 'i = "  \033[1;35m==A=L=T=O=R=K=Y==>>.....[ 3 ]\033[1;32m Install payload .............>\033[1;35m [ 13 ]\033[1;32m Hack Acount "' >> .ssss.py
echo 'j = "  "' >> .ssss.py
echo 'k = "  \033[1;35m==A=L=T=O=R=K=Y==>>.......[ 4 ]\033[1;32m Hacking photo ................>\033[1;35m [ 14 ]\033[1;32m Louk Account"' >> .ssss.py
echo 'l = "  "' >> .ssss.py
echo 'm = "  \033[1;35m==A=L=T=O=R=K=Y==>>.........[ 5 ]\033[1;32m Ngrok .........................>\033[1;35m [ 15 ]\033[1;32m Getting IP "' >> .ssss.py
echo 'n = "  "' >> .ssss.py
echo 'o = "  \033[1;35m==A=L=T=O=R=K=Y==>>.........[ 6 ]\033[1;32m AHT T0olss ....................>\033[1;35m [ 16 ]\033[1;32m Geting the root  "' >> .ssss.py
echo 'p = "  "' >> .ssss.py
echo 'q = "  \033[1;35m==A=L=T=O=R=K=Y==>>.......[ 7 ]\033[1;32m Send SmS ......................>\033[1;35m [ 17 ]\033[1;32m New Osif  "' >> .ssss.py
echo 'r = "  "' >> .ssss.py
echo 's = "  \033[1;35m==A=L=T=O=R=K=Y==>>.....[ 8 ]\033[1;32m Emails .......................>\033[1;35m [ 18 ]\033[1;32m Chat py termux  "' >> .ssss.py
echo 't = "  "' >> .ssss.py
echo 'u = "  \033[1;35m==A=L=T=O=R=K=Y==>>...[ 9 ]\033[1;31m VIRUS AHT ....................>  "' >> .ssss.py
echo 'v = "  "' >> .ssss.py
echo 'w = "  \033[1;35m==A=L=T=O=R=K=Y==>>.[ 10 ]\033[1;32m Distributions Linux .........>  "' >> .ssss.py
echo 'x = "  "' >> .ssss.py


echo 'kk(a)' >> .ssss.py
echo 'kk(b)' >> .ssss.py
echo 'kk(c)' >> .ssss.py
echo 'kk(d)' >> .ssss.py
echo 'kk(e)' >> .ssss.py
echo 'kk(f)' >> .ssss.py
echo 'kk(g)' >> .ssss.py
echo 'kk(h)' >> .ssss.py
echo 'kk(i)' >> .ssss.py
echo 'kk(j)' >> .ssss.py
echo 'kk(k)' >> .ssss.py
echo 'kk(l)' >> .ssss.py
echo 'kk(m)' >> .ssss.py
echo 'kk(n)' >> .ssss.py
echo 'kk(o)' >> .ssss.py
echo 'kk(p)' >> .ssss.py
echo 'kk(q)' >> .ssss.py
echo 'kk(r)' >> .ssss.py
echo 'kk(s)' >> .ssss.py
echo 'kk(t)' >> .ssss.py
echo 'kk(u)' >> .ssss.py
echo 'kk(v)' >> .ssss.py
echo 'kk(w)' >> .ssss.py
echo 'kk(x)' >> .ssss.py

python2 .ssss.py

}



echo -e "$green "
cat << "EOF"

  /$$$$$$  /$$   /$$ /$$$$$$$$  /$$   /$$                     /$$                          
 /$$__  $$| $$  | $$|__  $$__/ | $$  | $$                    | $$                          
| $$  \ $$| $$  | $$   | $$    | $$  | $$  /$$$$$$   /$$$$$$$| $$   /$$  /$$$$$$   /$$$$$$ 
| $$$$$$$$| $$$$$$$$   | $$    | $$$$$$$$ |____  $$ /$$_____/| $$  /$$/ /$$__  $$ /$$__  $$
| $$__  $$| $$__  $$   | $$    | $$__  $$  /$$$$$$$| $$      | $$$$$$/ | $$$$$$$$| $$  \__/
| $$  | $$| $$  | $$   | $$    | $$  | $$ /$$__  $$| $$      | $$_  $$ | $$_____/| $$      
| $$  | $$| $$  | $$   | $$ /$$| $$  | $$|  $$$$$$$|  $$$$$$$| $$ \  $$|  $$$$$$$| $$      
|__/  |__/|__/  |__/   |__/|__/|__/  |__/ \_______/ \_______/|__/  \__/ \_______/|__/      
                                                                                        V 7.0 

EOF
echo ''
chat
clear
echo -e "$red"
echo -e               			                     	$cyan '   Welcome to----->{'$green'2019'$cyan'}'$blue
sleep 0.1

cat << "EOF"
                              ..
                             *__*
                            * .. *
                           / >.^.<\
                          /.. . . .\
                         /.    ^   .\
                 _____,-”~    \ /   “~“-._____
             ,-~“     “~-.   V 7.0   .-~“     “~-.
           ,^             ^. `. .' ,^             ^.
          /  A     H    T   \  ^  /    H a c k e r  \
         Y___________________Y   Y___________________Y
         | |^~“|^   _ ^|“~^| |   | |“~“|^ _   ^|“~“| |
         | !   l   (_) !   ! l   | !   l (_)   !   ! |
         l  \  `\.___,/“  /  !   l  \  `\.___,/“  /  !
          \  ^.         ,^  /!   !\  ^.         ,^  /
           ^.  ~-------~  ,^\`v-v'/^.  ~-------~  ,^
             ~-._______,-~   }---{   ~-._______,-~
               \      aa  b   b     eee ddd    /
                \ \  a  a b   baa b e__ d  d  /
                 \   ahha bsssb a b e   d  d /
                  ]_ a  a b   b a b eee d d _[
                     ”x - x -  x - x -  x“
                       “XXXXXXXXXXXXXXXX“    

EOF

echo -e " ================================================================="
sleep 0.1
echo -e "                        $bluo H $green A $red k $purple E $cyan R "
sleep 0.2
echo -e $cyan "================================================================="
echo -e "$green use$blue ( ./AHT.sh --help )$purple for show option"
echo -e $cyan "================================================================="
echo ""
echo ""

chat2

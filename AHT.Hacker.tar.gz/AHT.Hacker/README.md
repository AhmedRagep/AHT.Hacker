


# AHT.Hacker
# py : Ahmed Altorky
# facebook : https://www.facebook.com/Ahmed.Altorky.Android
# youtube : https://www.youtube.com/channel/UCTUFvrUd3hIUNWzbVWJjBGQ
# watssapp : 01095616440
# install AHT.Hacker V 7.0

** apt update && apt upgrade -y

** pkg install git 

** git clone https://github.com/Ahmed-Altorky-Android/AHT.Hacker.git

** cd AHT.Hacker

** bash install.sh

** bash AHT.sh

                        Don Installed
